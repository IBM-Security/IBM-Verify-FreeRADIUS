#!/bin/bash
radtest sweeden@au1.ibm.com "$1" localhost 0 SECRET
